# dslab1
### Logging facility
#### Send message to Logging facility:
##### If you want to send file to Logging facility, append the message using
##### slash and T (/T), else just append slash and any character.
#### Print messages
##### Just by enter "p", all the messages in logging facility will be printed
##### in time stamp order, with the oldest messages on the top and newest on
##### the bottom. The concurrent messages will be printed together with
##### "concurrent" tag. Note that the duplicate message will be drop when log
##### receives it. Thus, duplicated message will not exist on Logging facility.
