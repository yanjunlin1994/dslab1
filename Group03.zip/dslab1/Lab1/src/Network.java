
public class Network {
	
}
